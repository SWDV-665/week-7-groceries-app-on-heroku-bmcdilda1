import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular/standalone';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonItem, IonItemSliding,
  IonLabel, IonItemOptions, IonItemOption, IonButton, IonToast, IonFab, IonFabButton, IonIcon,
  IonText, IonButtons, IonInput, IonSelect, IonSelectOption
} from '@ionic/angular/standalone';
import { Inventory } from '../inventory';
import { InventoryService } from '../inventoryservice.service';

@Component({
  selector: 'app-modal-input',
  templateUrl: './modal-input.component.html',
  styleUrls: ['./modal-input.component.scss'],
  standalone: true,
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonItem,
    IonItemSliding, IonLabel, IonItemOptions, IonItemOption, IonButton, IonToast,
    IonFab, IonFabButton, IonIcon, IonText, IonButtons, IonInput, CommonModule, FormsModule,
    IonSelect, IonSelectOption],
})
export class ModalInputComponent implements OnInit {
  _message: string = "Add Item";
  _name?: string;
  _quantity?: number;
  _serialNumber?: string;
  _purchaseDate?: string;
  _location?: string;
  _assetTag?: string;
  _picture?: string;
  _file?: string;
  _inventory?: Inventory;
  _index?: number;
  _editMode: boolean = false;

  
  _quantities: number[] = [];
  _quantitySize: number = 10;

  selectedFile: File | null = null; 

  constructor(private modalCtrl: ModalController,
              private inventoryServiceService: InventoryService) {
    for (let i = 1; i <= this._quantitySize; i++) {
      this._quantities.push(i);
    }
  }

  
  onFileSelected(event: any) {
    const file: File = event.target.files[0];
    this.selectedFile = file;
  }




  cancel() {
    return this.modalCtrl.dismiss(null, 'cancel');
  }

  confirm() {
    const name = this._name || "";
    const quantity = this._quantity || 0;
    const serialNumber = this._serialNumber || "";
    const purchaseDate = this._purchaseDate || "";
    const location = this._location || "";
    const assetTag = this._assetTag || "";
    const picture = this._picture || "";
    const file = this.selectedFile ? this.selectedFile.name : this._file || "";  

    if (!this._editMode) {
      if (name === "" || quantity === 0) {
        alert("All fields are required");
        return;
      }
      const newInventory = new Inventory("", name, quantity, serialNumber, purchaseDate, location, assetTag, picture, file);
      this.inventoryServiceService.addInventory(newInventory, this.selectedFile).subscribe();  
      if (this._inventory !== undefined && this._index !== undefined) {
        if (name === "" || quantity === 0) {
          alert("All fields are required");
          return;
        }
        this._inventory.setAssetName(name);
        this._inventory.setAssetQuantity(quantity);
        this._inventory.setSerialNumber(serialNumber);
        this._inventory.setPurchaseDate(purchaseDate);
        this._inventory.setLocation(location);
        this._inventory.setAssetTag(assetTag);
        this._inventory.setPicture(picture);
        this._inventory.setFile(file);
        this.inventoryServiceService.editInventory(this._inventory, this._index, this.selectedFile).subscribe();
      }
    }
    return this.modalCtrl.dismiss('confirm');
  }

  ngOnInit() {
    if (this._inventory !== undefined && this._index !== undefined) {
      this._name = this._inventory.getAssetName();
      this._quantity = this._inventory.getAssetQuantity();
      this._serialNumber = this._inventory.getSerialNumber();
      this._purchaseDate = this._inventory.getPurchaseDate();
      this._location = this._inventory.getLocation();
      this._assetTag = this._inventory.getAssetTag();
      this._picture = this._inventory.getPicture();
      this._file = this._inventory.getFile();
      this._editMode = true;
      this._message = "Edit Item";
    }
  }
}
