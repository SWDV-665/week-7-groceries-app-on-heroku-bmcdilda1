import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular/standalone';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonItem, IonItemSliding,
  IonLabel, IonItemOptions, IonItemOption, IonButton, IonToast, IonFab, IonFabButton, IonIcon,
  IonText, IonButtons, IonInput, IonSelect, IonSelectOption
} from '@ionic/angular/standalone';
import { Inventory } from '../inventory';
import { InventoryService } from '../inventoryservice.service';

@Component({
  selector: 'app-modal-input',
  templateUrl: './modal-input.component.html',
  styleUrls: ['./modal-input.component.scss'],
  standalone: true,
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonItem,
    IonItemSliding, IonLabel, IonItemOptions, IonItemOption, IonButton, IonToast,
    IonFab, IonFabButton, IonIcon, IonText, IonButtons, IonInput, CommonModule, FormsModule,
    IonSelect, IonSelectOption],
})
export class ModalInputComponent implements OnInit {
  _message: string = "Add Item";
  _name?: string;
  _quantity?: number;
  _serialNumber?: string;
  _purchaseDate?: string;
  _location?: string;
  _assetTag?: string;
  _picture?: string;
  _file?: string;
  _inventory?: Inventory;
  _index?: number;
  _editMode: boolean = false;

  _quantities: number[] = [];
  _quantitySize: number = 10;

  selectedFile: File | null = null; // **Added to handle file uploads**

  constructor(private modalCtrl: ModalController,
              private inventoryServiceService: InventoryService) {
    for (let i = 1; i <= this._quantitySize; i++) {
      this._quantities.push(i);
    }
  }

  onFileSelected(event: any) {
    const file: File = event.target.files[0];
    this.selectedFile = file; // **Updated to correctly handle file selection**
  }

  ngOnInit() {
    // Initialization code
  }

  cancel() {
    this.modalCtrl.dismiss();
  }

  confirm() {
    // Confirmation code
  }
}
